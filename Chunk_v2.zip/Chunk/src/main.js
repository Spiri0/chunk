import * as THREE from "../resources/libs/three/build/three.module.js";
import { OrbitControls } from '../resources/libs/three/examples/jsm/controls/OrbitControls.js';
import WebGL from '../resources/libs/three/examples/jsm/WebGL.js';


const P = new THREE.Vector3();
const N1 = new THREE.Vector3();
const N2 = new THREE.Vector3();
const N3 = new THREE.Vector3();
const D1 = new THREE.Vector3();
const D2 = new THREE.Vector3();


const VS = `

	precision highp float;
	precision highp int;

	uniform mat4 modelMatrix;
	uniform mat4 modelViewMatrix;
	uniform mat4 viewMatrix;
	uniform mat4 projectionMatrix;
	uniform vec3 cameraPosition;

	uniform float time;
	uniform int point;

	// Attributes
	in vec3 position;
	in vec3 normal;
	in int index;
	in int vindex;
	// Outputs
	out vec3 vNormal;


	void main() { 	

		vNormal = normalize(normal);	
		vec3 newPosition = position + vNormal * 3.;
				
		gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
		
		if(vindex == point){
			gl_Position = projectionMatrix * modelViewMatrix * vec4(newPosition, 1.0);
		}
		
}`;


const FS = `

	#define PI 3.141592653589793238
	#define FLT_MAX 3.402823466e+38

	precision highp float;
	precision highp int;
	precision highp sampler2DArray;
	precision highp sampler3D;

	uniform vec3 color;
		

	in vec3 vNormal;

	out vec4 out_FragColor;
	

void main() {

	out_FragColor = vec4(vec3(1., 0., 0.), 1.);

}`;





async function main() {
	new Main();
}


class Main {
	constructor(){
		this.init();
		this.animate();	
	}
			
	init(){
		
		if (!WebGL.isWebGL2Available()) {
    		return false;
		}
	
		const canvas = document.createElement('canvas');
		const context = canvas.getContext('webgl2');
	
		this.renderer = new THREE.WebGLRenderer({ 
			canvas: canvas,
			context: context,
			antialias: true
		});
		
				
		this.renderer.setPixelRatio( window.devicePixelRatio ); 
		this.renderer.shadowMap.enabled = true; 
		this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
		//this.renderer.autoClear = false;
		
		this.container = document.getElementById('container');
		this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
		this.container.appendChild( this.renderer.domElement );

		this.aspect = this.container.clientWidth / this.container.clientHeight; 
		this.scene = new THREE.Scene();
		this.scene.background = new THREE.Color( 0x557799 );
		this.camera = new THREE.PerspectiveCamera( 50, this.aspect, 0.1, 10000000 );
		//this.camera.position.set(0, 0, 50);
		this.camera.position.set( 30, 20, -30 );
	
		this.controls = new OrbitControls( this.camera, this.renderer.domElement );
		this.controls.screenSpacePanning = true;
		this.controls.minDistance = 5;
		this.controls.maxDistance = 40;
		this.controls.target.set( 0, 2, 0 );
		this.controls.update();
	
	
		this.clock = new THREE.Clock();
	
	
	
	

		this.params = {
			resolution: 5,
			offset: new THREE.Vector3(0, 0, 0),
			width: 20,
		}


		const positions = [];
		const vertexIndex = [];

		const resolution = this.params.resolution;
		const offset = this.params.offset;
		const width = this.params.width;
		const half = width / 2;
  
  		let idx = 0;
        
		for (let x = 0; x <= resolution; x++) {
			const xp = width * x / resolution;
			for (let z = 0; z <= resolution; z++) {
				const zp = width * z / resolution;
				// Compute position
				P.set(xp - half, 0, zp - half);
				P.add(offset);

				positions.push(P.x, P.y, P.z);
				vertexIndex.push(idx);
				idx += 1;
			}
		}

		// Generate indices and normals
		const indices = this.GenerateIndices();
		const normals = this.GenerateNormals(positions, indices);

		const bytesInFloat32 = 4;
		const bytesInInt32 = 4;
		const positionsArray = new Float32Array(new ArrayBuffer(bytesInFloat32 * positions.length));
		const normalsArray = new Float32Array(new ArrayBuffer(bytesInFloat32 * normals.length));
		const indicesArray = new Uint32Array(new ArrayBuffer(bytesInInt32 * indices.length));
		const vIndicesArray = new Uint32Array(new ArrayBuffer(bytesInInt32 * vertexIndex.length));


		positionsArray.set(positions, 0);
		normalsArray.set(normals, 0);
		indicesArray.set(indices, 0);
		vIndicesArray.set(vertexIndex, 0);


		var uniform = {
			color: {value: new THREE.Vector3(20/255, 50/255, 120/255)},
			time: {value: 0},
			point: {value: -1},
		}


		this.material = new THREE.RawShaderMaterial({
			glslVersion: THREE.GLSL3,
			uniforms: uniform,
			vertexShader: VS,
			fragmentShader: FS,
			side: THREE.DoubleSide,
			wireframe: true,
		});



		this.geometry = new THREE.BufferGeometry();	
		this.mesh = new THREE.Mesh(this.geometry, this.material);
		this.mesh.castShadow = false;
		this.mesh.receiveShadow = true;
		this.mesh.frustumCulled = false;
		this.mesh.position.set(0, 0, 0);  
		this.mesh.rotation.x = Math.PI;
		this.geometry.setAttribute('position', new THREE.Float32BufferAttribute(positionsArray, 3));
		this.geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normalsArray, 3));
		this.geometry.setAttribute('index', new THREE.Int32BufferAttribute(indicesArray, 1));
		this.geometry.setAttribute('vindex', new THREE.Int32BufferAttribute(vIndicesArray, 1));
		this.geometry.setIndex(new THREE.BufferAttribute(indicesArray, 1));
		
		this.geometry.attributes.position.needsUpdate = true;
		this.geometry.attributes.normal.needsUpdate = true;
		this.geometry.attributes.index.needsUpdate = true;
		this.geometry.attributes.vindex.needsUpdate = true;
	
		this.scene.add( this.mesh );


		const ambientLight = new THREE.AmbientLight( 0xffffff, 0.2 );
		this.scene.add( ambientLight );

		const pointLight = new THREE.PointLight( 0xffffff, 0.8 );
		this.scene.add( this.camera );
		this.camera.add( pointLight );
	
	
	}//end init
	
	
	
	GenerateNormals(positions, indices) {
    const normals = new Array(positions.length).fill(0.0);
    for (let i = 0, n = indices.length; i < n; i+= 3) {
      const i1 = indices[i] * 3;
      const i2 = indices[i+1] * 3;
      const i3 = indices[i+2] * 3;

      N1.fromArray(positions, i1);
      N2.fromArray(positions, i2);
      N3.fromArray(positions, i3);

      D1.subVectors(N3, N2);
      D2.subVectors(N1, N2);
      D1.cross(D2);

      normals[i1] += D1.x;
      normals[i2] += D1.x;
      normals[i3] += D1.x;

      normals[i1+1] += D1.y;
      normals[i2+1] += D1.y;
      normals[i3+1] += D1.y;

      normals[i1+2] += D1.z;
      normals[i2+2] += D1.z;
      normals[i3+2] += D1.z;
    }
    return normals;
  }

  GenerateIndices() {
    const resolution = this.params.resolution;
    const indices = [];
    for (let i = 0; i < resolution; i++) {
      for (let j = 0; j < resolution; j++) {
        indices.push(
            i * (resolution + 1) + j,
            (i + 1) * (resolution + 1) + j + 1,
            i * (resolution + 1) + j + 1);
        indices.push(
            (i + 1) * (resolution + 1) + j,
            (i + 1) * (resolution + 1) + j + 1,
            i * (resolution + 1) + j);
      }
    }
    return indices;
  }
	
	
	
	
	
	
	animate(){
		//requestAnimationFrame( this.animate );  
		requestAnimationFrame( this.animate.bind(this) );  
		this.render();
	}//end animate
	
	
	render(){
		
		//this.controls.update();
		this.camera.updateMatrixWorld();
		this.camera.updateProjectionMatrix(); 
	
		this.renderer.render(this.scene, this.camera); 


		var index = document.getElementById("testfield1").value;
		if(index == ''){
			this.mesh.material.uniforms.point.value = 100000000000;
		}
		else{
			this.mesh.material.uniforms.point.value = index;
		}
		this.mesh.material.uniformsNeedUpdate = true;

	}//end render
}//end class


export {main};