import {main} from "./main.js"; 
await main();